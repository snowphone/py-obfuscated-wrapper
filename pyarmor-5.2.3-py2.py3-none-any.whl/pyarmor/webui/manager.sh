#! /usr/bin/env bash
cd $(dirname $0)
python server.py
