requirejs.config({
    baseUrl: 'js'
});

requirejs(['main']);
