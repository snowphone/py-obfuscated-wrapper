# Package pyarmor
import sys
from os.path import abspath, dirname
sys.path.insert(0, abspath(dirname(__file__)))
