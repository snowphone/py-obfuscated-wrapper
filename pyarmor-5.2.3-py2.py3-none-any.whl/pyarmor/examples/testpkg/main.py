from mypkg import title
from mypkg.foo import hello

hello(title)
